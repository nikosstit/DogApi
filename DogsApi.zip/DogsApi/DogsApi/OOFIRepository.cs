﻿using DogsApi.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DogsApi
{
    public interface IRepository
    {
        //void AddBreed(Breed breed);
        //Task<List<Breed>> GetAllBreeds();
        //Entities.Breed GetBreedById(int Id);
    }
}
