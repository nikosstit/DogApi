﻿using DogsApi.Entities;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System;

namespace DogsApi
{
    [Route("api/breeds")]
    [ApiController]
    public class BreedsController: ControllerBase
    {
        //private readonly IRepository _repository;
        private readonly ILogger<BreedsController> logger;
        private ApplicationDbContext context;
        public BreedsController(ILogger<BreedsController> logger,
            ApplicationDbContext context)
        {
            this.logger = logger;
            this.context = context;
        }

        //retrieve data from db
        [HttpGet]
        public async Task<ActionResult<List<Breed>>> Get()
        {
            //logger.LogInformation("Getting All the breeds");
            //return await _repository.GetAllBreeds();
            return await context.Breeds.AsNoTracking().ToListAsync();
        }

        [HttpGet("{Id}")] //General Type
        public async Task<ActionResult <Breed>>Get(int Id)
        {
            var breed = await context.Breeds.FirstOrDefaultAsync(x => x.Id == Id);

            if (breed == null)
            {
                //logger.LogWarning($"Breed with {Id} not found");
                return NotFound();
            }
            return breed;
        }

        [HttpPost]
        public async Task<ActionResult> Post([FromBody] Breed breed)
        {
            context.Add(breed);
            await context.SaveChangesAsync();
            return new CreatedAtRouteResult("GetAllBreeds", new { Id = breed.Id}, breed);
        }

        [HttpPut]
        public ActionResult Put([FromBody] Breed breed)
        {
            //if (!ModelState.IsValid)
            //{
            //    return BadRequest(ModelState);
            //}
            return NoContent();
        }

        [HttpDelete]
        public ActionResult Delete([FromBody] Breed breed)
        {
            return NoContent();
        }

    }
}
